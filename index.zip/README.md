# uploadObjectUsingPreSignedURL
A repository which demonstrate the pre-signed URL concept to upload an object file to S3 using Boto3 framework of Python and AWS Lambda Function.. 
