import json
import logging
import boto3
import os
import requests
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    # Get object name from event payload
    print(event)
    object_name = event['object_name']

    # Get all environment variables value
    bucket_name = os.environ["BUCKET_NAME"]
    expiration_limit = os.environ["EXPIRATION"]
    print("Bucket name is :"+bucket_name)
    print("Object expiration is :"+expiration_limit)
    
    # Generate Pre-signed URL to generate for S3 object
    s3_client = boto3.client('s3')
    try:
        response = s3_client.generate_presigned_url('get_object',Params={'Bucket': bucket_name,'Key': object_name},ExpiresIn=expiration_limit)
        
        if response is None:
            return {
                'statusCode': 200,
                'body': json.dumps('Unable to get pre-signed URL.')
            }
        else:
            #Upload a file on S3 once the pre-signed URL has been generated
            with open(object_name, 'rb') as f:
                files = {'file': (object_name, f)}
                http_response = requests.post(response['url'], data=response['fields'], files=files)
            logging.info(f'File upload HTTP status code: {http_response.status_code}')
            return {
                'statusCode': 200,
                'body': json.dumps('Data file uploaded to S3 successfully.')
            }
    except ClientError as e:
        logging.error(e)
        return {
            'statusCode': 200,
            'body': json.dumps('Problem occured while generating the pre-signed URL.')
        }
    return {
        'statusCode': 200,
        'body': json.dumps('The pre-signed URL {} for the object {} has been generated successfully.'.format(response,object_name))
    }
